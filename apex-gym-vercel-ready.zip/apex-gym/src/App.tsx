import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ArrowRight, ArrowUpRight, Check, Clock3, Dumbbell, Facebook, Instagram, Mail, MapPin, Menu, Music2, Phone, X, Youtube } from 'lucide-react';
import { motion } from 'framer-motion';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

type ClassItem = {
  id: string;
  number: string;
  name: string;
  meta: string;
  detail: string;
  description: string;
};

type ScheduleItem = {
  time: string;
  name: string;
  coach: string;
  level: string;
};

const classes: ClassItem[] = [
  { id: '01', number: '01 / 06', name: 'HIIT', meta: '45 MIN / INTERMEDIATE', detail: 'Intervals, sleds, and lungs on fire.', description: 'High-output intervals that build speed, power, and the ability to find another gear.' },
  { id: '02', number: '02 / 06', name: 'Strength & Conditioning', meta: '60 MIN / ALL LEVELS', detail: 'Compound lifts and intelligent conditioning.', description: 'Progressive strength work paired with conditioning that keeps you durable outside the gym.' },
  { id: '03', number: '03 / 06', name: 'Boxing', meta: '50 MIN / INTERMEDIATE', detail: 'Footwork, pads, and disciplined aggression.', description: 'Coach-led rounds for sharper movement, cleaner combinations, and serious conditioning.' },
  { id: '04', number: '04 / 06', name: 'Spin', meta: '45 MIN / ALL LEVELS', detail: 'Ride hard. Recover smarter.', description: 'Rhythm-led intervals on the bike with a room full of energy and no spectators.' },
  { id: '05', number: '05 / 06', name: 'Yoga', meta: '60 MIN / ALL LEVELS', detail: 'Breathe deep. Move better.', description: 'A focused reset for mobility, balance, and the kind of recovery that compounds.' },
  { id: '06', number: '06 / 06', name: 'Mobility', meta: '45 MIN / ALL LEVELS', detail: 'Own your range of motion.', description: 'Structured movement work to help you lift, run, and train with more control.' },
];

const schedules: Record<string, ScheduleItem[]> = {
  MON: [
    { time: '06:30', name: 'Strength & Conditioning', coach: 'Arif R.', level: 'ALL LEVELS' },
    { time: '08:00', name: 'HIIT', coach: 'Tanvir H.', level: 'INTERMEDIATE' },
    { time: '18:30', name: 'Boxing', coach: 'Tanvir H.', level: 'ALL LEVELS' },
    { time: '20:00', name: 'Strength & Conditioning', coach: 'Arif R.', level: 'ALL LEVELS' },
  ],
  TUE: [
    { time: '07:00', name: 'HIIT', coach: 'Tanvir H.', level: 'ALL LEVELS' },
    { time: '18:00', name: 'Strength & Conditioning', coach: 'Arif R.', level: 'ALL LEVELS' },
    { time: '19:30', name: 'Boxing', coach: 'Tanvir H.', level: 'INTERMEDIATE' },
  ],
  WED: [
    { time: '06:30', name: 'Boxing', coach: 'Tanvir H.', level: 'ALL LEVELS' },
    { time: '08:00', name: 'Strength & Conditioning', coach: 'Arif R.', level: 'ALL LEVELS' },
    { time: '18:30', name: 'HIIT', coach: 'Tanvir H.', level: 'ALL LEVELS' },
  ],
  THU: [
    { time: '07:00', name: 'Strength & Conditioning', coach: 'Arif R.', level: 'ALL LEVELS' },
    { time: '18:00', name: 'HIIT', coach: 'Tanvir H.', level: 'INTERMEDIATE' },
    { time: '20:00', name: 'Boxing', coach: 'Tanvir H.', level: 'ALL LEVELS' },
  ],
  FRI: [
    { time: '08:00', name: 'HIIT', coach: 'Tanvir H.', level: 'ALL LEVELS' },
    { time: '17:30', name: 'Boxing', coach: 'Tanvir H.', level: 'ALL LEVELS' },
    { time: '19:00', name: 'Strength & Conditioning', coach: 'Arif R.', level: 'ALL LEVELS' },
  ],
  SAT: [
    { time: '09:00', name: 'Yoga', coach: 'Nushrat A.', level: 'ALL LEVELS' },
    { time: '10:30', name: 'Spin', coach: 'Nushrat A.', level: 'ALL LEVELS' },
    { time: '12:00', name: 'Mobility', coach: 'Nushrat A.', level: 'ALL LEVELS' },
  ],
  SUN: [
    { time: '09:00', name: 'Mobility', coach: 'Nushrat A.', level: 'ALL LEVELS' },
    { time: '10:30', name: 'Strength & Conditioning', coach: 'Arif R.', level: 'ALL LEVELS' },
    { time: '18:00', name: 'HIIT', coach: 'Tanvir H.', level: 'INTERMEDIATE' },
  ],
};

const monthlyPlans = [
  { name: 'Flex', price: '৳2,500', detail: 'Off-peak access, basic equipment, locker, fitness assessment.', note: 'Good place to start' },
  { name: 'Full Access', price: '৳4,000', detail: 'Unlimited access, 8 group classes/mo, training program, community.', note: 'Most popular' },
  { name: 'APEX All-In', price: '৳6,500', detail: 'Unlimited classes, 1 PT session/mo, priority booking.', note: 'Go further' },
];

const quarterlyPlans = [
  { name: 'Flex', price: '৳6,750', detail: 'Off-peak access, basic equipment, locker, fitness assessment.', note: 'Save 10%' },
  { name: 'Full Access', price: '৳10,800', detail: 'Unlimited access, 8 group classes/mo, training program, community.', note: 'Save 10%' },
  { name: 'APEX All-In', price: '৳17,550', detail: 'Unlimited classes, 1 PT session/mo, priority booking.', note: 'Save 10%' },
];

const dayLabels = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];

const trainers = [
  { name: 'Arif Rahman', role: 'Strength & Conditioning', image: 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { name: 'Nushrat Ahmed', role: 'Performance & Mobility', image: 'https://images.pexels.com/photos/3768916/pexels-photo-3768916.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { name: 'Tanvir Hossain', role: 'Boxing & Conditioning', image: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=900' },
];

const testimonials = [
  { quote: 'I came in looking for equipment and stayed for the standard. Every session has intent here.', name: 'Rafi', detail: 'APEX member / Banani' },
  { quote: 'The coaches remember what you are working toward. That changes how you show up.', name: 'Samira', detail: 'APEX member / Gulshan' },
  { quote: 'APEX is the first place where training became part of my week, not another thing to postpone.', name: 'Fahim', detail: 'APEX member / Dhanmondi' },
];

function useReveal() {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (!('IntersectionObserver' in window)) {
      setVisible(true);
      return;
    }
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setVisible(true);
        observer.disconnect();
      }
    }, { threshold: 0.12 });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return { ref, visible };
}

function useCountUp(target: number, suffix: string) {
  const [value, setValue] = useState(0);
  const { ref, visible } = useReveal();
  useEffect(() => {
    if (!visible) return;
    const start = performance.now();
    const duration = 1200;
    let frame = 0;
    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      setValue(Math.round(target * (1 - Math.pow(1 - progress, 3))));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target, visible]);
  return { ref, value: `${value}${suffix}` };
}

function Reveal({ children, className = '', delay = '' }: { children: ReactNode; className?: string; delay?: string }) {
  const { ref, visible } = useReveal();
  return <div ref={ref} className={`reveal ${visible ? 'visible' : ''} ${delay} ${className}`}>{children}</div>;
}

function Stat({ target, suffix, label }: { target: number; suffix: string; label: string }) {
  const counted = useCountUp(target, suffix);
  return <div className="stat" ref={counted.ref} data-testid={`stat-${label.toLowerCase().replaceAll(' ', '-')}`}>
    <div className="stat-value">{counted.value}</div>
    <div className="stat-label">{label}</div>
  </div>;
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeClass, setActiveClass] = useState<string | null>(null);
  const [activeDay, setActiveDay] = useState('MON');
  const [selectedPlan, setSelectedPlan] = useState('Full Access');
  const [billing, setBilling] = useState<'monthly' | 'quarterly'>('monthly');
  const [booking, setBooking] = useState<{ className?: string; plan?: string } | null>(null);
  const [bookingSubmitted, setBookingSubmitted] = useState(false);
  const [bookingSubmitting, setBookingSubmitting] = useState(false);
  const [formStatus, setFormStatus] = useState('');
  const [leadSubmitting, setLeadSubmitting] = useState(false);
  const [email, setEmail] = useState('');
  const bookingCloseRef = useRef<HTMLButtonElement | null>(null);
  const leadTimeoutRef = useRef<number | null>(null);
  const bookingTimeoutRef = useRef<number | null>(null);

  const selectedSchedule = useMemo(() => schedules[activeDay] ?? [], [activeDay]);
  const closeMenu = () => setMenuOpen(false);
  const closeBooking = () => {
    if (bookingTimeoutRef.current) window.clearTimeout(bookingTimeoutRef.current);
    setBookingSubmitting(false);
    setBooking(null);
  };
  const openTrial = (plan?: string) => {
    if (bookingTimeoutRef.current) window.clearTimeout(bookingTimeoutRef.current);
    setBookingSubmitted(false);
    setBookingSubmitting(false);
    setBooking({ plan: plan ?? selectedPlan });
  };

  useEffect(() => {
    const lockScroll = menuOpen || Boolean(booking);
    const previousOverflow = document.body.style.overflow;
    if (lockScroll) document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [menuOpen, booking]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 900) setMenuOpen(false);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (!booking) return;
    bookingCloseRef.current?.focus();
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') closeBooking();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [booking]);

  useEffect(() => () => {
    if (leadTimeoutRef.current) window.clearTimeout(leadTimeoutRef.current);
    if (bookingTimeoutRef.current) window.clearTimeout(bookingTimeoutRef.current);
  }, []);

  const submitLead = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (leadSubmitting) return;
    if (!email.trim()) {
      setFormStatus('Drop an email in first — we will keep it useful.');
      return;
    }
    const form = event.currentTarget;
    setLeadSubmitting(true);
    setFormStatus('Checking your details...');
    leadTimeoutRef.current = window.setTimeout(() => {
      setLeadSubmitting(false);
      setFormStatus('Demo confirmation — no information was sent.');
      setEmail('');
      form.reset();
    }, 350);
  };

  const submitBooking = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (bookingSubmitting || bookingSubmitted) return;
    setBookingSubmitting(true);
    bookingTimeoutRef.current = window.setTimeout(() => {
      setBookingSubmitting(false);
      setBookingSubmitted(true);
    }, 350);
  };

  const stats = [
    { target: 1000, suffix: '+', label: 'MEMBERS' },
    { target: 30, suffix: '+', label: 'CLASSES / WEEK' },
    { target: 3, suffix: '', label: 'TRAINING ZONES' },
    { target: 11, suffix: 'PM', label: 'OPEN DAILY FROM 6AM' },
  ];
  const plans = billing === 'monthly' ? monthlyPlans : quarterlyPlans;

  return (
    <div className="apex-shell">
      <header className="site-header">
        <div className="page-wrap header-inner">
          <a className="brand-lockup" href="#top" onClick={closeMenu} data-testid="link-brand">
            <span className="brand-mark" aria-hidden="true"><Dumbbell size={17} strokeWidth={2.4} /></span>
            <span><span className="brand-word">APEX</span><span className="brand-sub">Training culture / Banani</span></span>
          </a>
          <nav className="header-nav" aria-label="Main navigation">
            <a href="#classes" data-testid="link-classes">Classes</a>
            <a href="#facility" data-testid="link-facility">Facility</a>
            <a href="#schedule" data-testid="link-schedule">Timetable</a>
            <a href="#membership" data-testid="link-membership">Membership</a>
            <a href="#trainers" data-testid="link-trainers">Trainers</a>
          </nav>
          <button className="header-cta" onClick={() => openTrial()} data-testid="button-header-join">
            Join free trial <ArrowUpRight size={15} aria-hidden="true" />
          </button>
          <button className="menu-button" type="button" onClick={() => setMenuOpen((open) => !open)} aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen} aria-controls="mobile-navigation" data-testid="button-mobile-menu">
            {menuOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
        <motion.nav id="mobile-navigation" className={`mobile-menu ${menuOpen ? 'open' : ''}`} aria-label="Mobile navigation" aria-hidden={!menuOpen} initial={false} animate={{ opacity: menuOpen ? 1 : 0, y: menuOpen ? 0 : -18 }} transition={{ type: 'spring', stiffness: 280, damping: 26 }}>
          <a href="#classes" onClick={closeMenu} tabIndex={menuOpen ? 0 : -1} data-testid="mobile-link-classes">Classes</a>
          <a href="#facility" onClick={closeMenu} tabIndex={menuOpen ? 0 : -1} data-testid="mobile-link-facility">Facility</a>
          <a href="#schedule" onClick={closeMenu} tabIndex={menuOpen ? 0 : -1} data-testid="mobile-link-schedule">Timetable</a>
          <a href="#membership" onClick={closeMenu} tabIndex={menuOpen ? 0 : -1} data-testid="mobile-link-membership">Membership</a>
          <a href="#trainers" onClick={closeMenu} tabIndex={menuOpen ? 0 : -1} data-testid="mobile-link-trainers">Trainers</a>
          <a className="mobile-join" href="#contact" onClick={closeMenu} tabIndex={menuOpen ? 0 : -1} data-testid="mobile-link-join">Claim your first session</a>
        </motion.nav>
      </header>

      <main id="top">
        <section className="hero" aria-labelledby="hero-title">
          <div className="page-wrap hero-content">
            <Reveal>
              <span className="eyebrow hero-kicker">00 — Premium fitness · Dhaka, Bangladesh</span>
              <h1 className="display-xl hero-title" id="hero-title">Train hard.<br /><span>Recover smart.</span><br />Repeat.</h1>
            </Reveal>
            <Reveal delay="delay-2">
              <div className="hero-bottom">
                <p className="hero-copy">Premium equipment, expert coaches, and high-energy classes built for people who take their progress seriously.</p>
                <div className="hero-actions">
                  <button className="btn-primary" onClick={() => openTrial()} data-testid="button-hero-trial">Start free trial <ArrowUpRight size={16} /></button>
                  <a className="btn-ghost" href="#classes" data-testid="link-hero-classes">Explore classes <ArrowRight size={16} /></a>
                </div>
                <div className="hero-trust">7 days free <span>·</span> no credit card <span>·</span> no commitment</div>
                <div className="hero-mini-stats"><span><strong>30+</strong> classes / wk</span><span><strong>1,000+</strong> members</span><span><strong>6AM–11PM</strong> daily</span></div>
                <div className="hero-scroll"><span className="scroll-line" /> Scroll to train</div>
              </div>
            </Reveal>
          </div>
          <div className="vertical-tag">23.7937° N / 90.4066° E</div>
        </section>

        <div className="marquee" aria-label="APEX training principles">
          <div className="marquee-track">
            {['Train with intent', 'No spectators', 'Built in Banani', 'Earn your edge', 'Train with intent', 'No spectators', 'Built in Banani', 'Earn your edge'].map((item, index) => <span className="marquee-item" key={`${item}-${index}`}>{item}</span>)}
          </div>
        </div>

        <section className="manifesto section-space" id="method">
          <div className="page-wrap manifesto-grid">
            <Reveal>
              <span className="eyebrow">The APEX standard</span>
              <h2 className="display-md manifesto-title">Comfort is<br /><em>expensive.</em></h2>
              <div className="manifesto-stamp">No shortcuts<br />since 2024</div>
            </Reveal>
            <Reveal delay="delay-2" className="manifesto-copy">
              <p>APEX is not a room full of machines. It is a training culture with a pulse — coached sessions, honest effort, and people who show up ready to be sharpened.</p>
              <small>From serious beginners finding their first clean rep to athletes building the next season, every session has a purpose. We keep the room focused, the programming intelligent, and the standard high.</small>
            </Reveal>
          </div>
        </section>

        <section className="stats" aria-label="APEX at a glance">
          <div className="page-wrap stats-grid">
            {stats.map((stat) => <Stat key={stat.label} {...stat} />)}
          </div>
        </section>

        <section className="training section-space" id="classes">
          <div className="page-wrap">
            <Reveal className="section-heading">
              <div><span className="eyebrow">01 — Classes</span><h2 className="display-md">The work<br />has names.</h2></div>
              <p>Tap a class to see what it asks of you. Every format is coached, capped, and built to move you forward.</p>
            </Reveal>
            <div className="class-grid">
              {classes.map((item) => {
                const active = activeClass === item.id;
                return <button className={`class-card ${active ? 'active' : ''}`} key={item.id} onClick={() => setActiveClass(active ? null : item.id)} aria-expanded={active} data-testid={`button-class-${item.id}`}>
                  <div className="class-num">{item.number}</div>
                  <div>
                    <h3 className="class-name">{item.name}</h3>
                    <p className="class-detail">{item.detail}<br /><span>{item.description}</span></p>
                  </div>
                  <div className="class-meta"><span>{item.meta}</span><span className="class-arrow" aria-hidden="true">↗</span></div>
                </button>;
              })}
            </div>
          </div>
        </section>

        <section className="schedule section-space" id="schedule">
          <div className="page-wrap">
            <Reveal className="schedule-top">
              <div><span className="eyebrow">Show up</span><h2 className="display-md">Train on<br />your time.</h2></div>
              <div className="day-tabs" role="tablist" aria-label="Choose a timetable day">
                {dayLabels.map((day) => <button className={`day-tab ${activeDay === day ? 'active' : ''}`} role="tab" aria-selected={activeDay === day} aria-controls="schedule-list" aria-label={`Show ${day} timetable`} onClick={() => setActiveDay(day)} key={day} data-testid={`button-day-${day.toLowerCase()}`}>{day}</button>)}
              </div>
            </Reveal>
            <div className="schedule-list" id="schedule-list" role="tabpanel" aria-live="polite" data-testid={`schedule-list-${activeDay.toLowerCase()}`}>
              {selectedSchedule.length ? selectedSchedule.map((item) => <div className="schedule-row" key={`${activeDay}-${item.time}-${item.name}`}>
                <div className="schedule-time"><Clock3 size={14} strokeWidth={1.7} aria-hidden="true" /> {item.time}</div>
                <div className="schedule-class">{item.name}</div>
                <div className="schedule-coach">{item.coach}</div>
                <div className="schedule-level">{item.level}</div>
                <button className="book-link" onClick={() => setBooking({ className: item.name })} data-testid={`button-book-${activeDay.toLowerCase()}-${item.time.replace(':', '')}`}>Book <ArrowUpRight size={13} /></button>
              </div>) : <div className="empty-schedule">Rest day. The room is quiet, but your plan does not have to be. Check another day.</div>}
            </div>
          </div>
        </section>

        <section className="facility section-space" id="facility" aria-labelledby="facility-title">
          <div className="page-wrap facility-layout">
            <Reveal className="facility-visual"><span className="facility-tag">A room with standards</span></Reveal>
            <Reveal delay="delay-2" className="facility-copy">
               <span className="eyebrow">02 — Facility</span>
               <h2 className="display-md" id="facility-title">Built to<br /><span style={{ color: 'var(--orange)' }}>train.</span></h2>
               <p>10,000+ square feet of serious training space in the heart of Banani. Every zone has a job.</p>
              <ul className="feature-list">
                 <li><span><b>01</b> Strength Zone — Power racks, Olympic platforms, free weights</span><span>10,000+ SQ FT</span></li>
                 <li><span><b>02</b> Performance Zone — Treadmills, bikes, rowers, functional gear</span><span>50+ MACHINES</span></li>
                 <li><span><b>03</b> Studio — HIIT, boxing, yoga & group training spaces</span><span>3 STUDIOS</span></li>
              </ul>
            </Reveal>
          </div>
        </section>

        <section className="pricing section-space" id="membership">
          <div className="page-wrap">
            <Reveal className="pricing-heading">
              <div><span className="eyebrow">03 — Membership</span><h2 className="display-md">Choose your<br />commitment.</h2></div>
              <div className="billing-wrap">
                <div className="billing-toggle" role="group" aria-label="Choose billing period">
                  <button className={billing === 'monthly' ? 'active' : ''} onClick={() => setBilling('monthly')}>Monthly</button>
                  <button className={billing === 'quarterly' ? 'active' : ''} onClick={() => setBilling('quarterly')}>Quarterly <span>Save 10%</span></button>
                </div>
                <p>No joining fee. No mystery terms. Pick the rhythm that keeps you honest.</p>
              </div>
            </Reveal>
            <div className="price-grid">
              {plans.map((plan) => {
                const selected = selectedPlan === plan.name;
                 return <div className={`price-card ${selected ? 'selected' : ''}`} key={plan.name} role="button" tabIndex={0} aria-pressed={selected} onClick={() => setSelectedPlan(plan.name)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); setSelectedPlan(plan.name); } }} data-testid={`card-plan-${plan.name.toLowerCase().replaceAll(' ', '-')}`}>
                  <div className="price-popular">{plan.note}</div>
                  <div className="price-name">{plan.name}</div>
                   <div className="price-amount">{plan.price} <small>{billing === 'monthly' ? '/ MONTH' : '/ 3 MONTHS'}</small></div>
                  <div className="price-info"><span>{plan.detail}</span><Check size={18} aria-hidden="true" /></div>
                   <button className="price-action" onClick={(event) => { event.stopPropagation(); setSelectedPlan(plan.name); openTrial(plan.name); }} data-testid={`button-select-${plan.name.toLowerCase().replaceAll(' ', '-')}`}>{plan.name === 'Flex' ? 'Choose flex' : plan.name === 'Full Access' ? 'Start training' : 'Go all-in'} <ArrowUpRight size={14} /></button>
                </div>;
              })}
            </div>
          </div>
        </section>

        <section className="trainers section-space" id="trainers">
          <div className="page-wrap">
            <Reveal className="section-heading"><div><span className="eyebrow">04 — Coaches</span><h2 className="display-md">People who know<br />how to train.</h2></div><p>Technique first. Ego last. The right coach changes what you think you can do.</p></Reveal>
            <div className="trainer-grid">{trainers.map((trainer) => <article className="trainer-card" key={trainer.name}><div className="trainer-image"><img src={trainer.image} alt={`${trainer.name}, ${trainer.role}`} loading="lazy" /></div><div className="trainer-meta"><h3>{trainer.name}</h3><p>{trainer.role}</p></div></article>)}</div>
          </div>
        </section>

        <section className="testimonial section-space" id="testimonials">
          <div className="page-wrap">
            <Reveal className="section-heading"><div><span className="eyebrow">05 — Testimonials</span><h2 className="display-md">Members who<br />show up.</h2></div></Reveal>
            <div className="testimonial-grid">{testimonials.map((item) => <article className="quote-card" key={item.name}><div className="stars" aria-label="5 out of 5 stars">★★★★★</div><blockquote>“{item.quote}”</blockquote><div className="quote-byline">{item.name}<span>{item.detail}</span></div></article>)}</div>
          </div>
        </section>

        <section className="contact section-space" id="contact">
          <div className="page-wrap contact-layout">
            <Reveal>
              <span className="eyebrow">Location & contact</span>
              <h2 className="display-lg">Your first 7 days<br /><span className="lime">are free.</span></h2>
              <p className="contact-copy">No credit card. No long-term commitment. Just come in and train.</p>
              <div className="contact-meta" style={{ display: 'flex', gap: '18px', flexWrap: 'wrap', marginTop: '35px', color: 'rgba(240,238,229,.52)', font: '500 10px/1.4 var(--app-font-mono)', textTransform: 'uppercase' }}>
                 <span><MapPin size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} />Road 11, Banani, Dhaka · demo address</span>
                <span><Clock3 size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} />Everyday · 6AM–11PM</span>
                 <a href="tel:+8801000000000" aria-label="Call the APEX demo number"><Phone size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} />+880 1000-000000 · demo</a>
                 <a href="mailto:hello@apexgym.demo" aria-label="Email the APEX demo inbox"><Mail size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} />hello@apexgym.demo</a>
              </div>
              <a className="direction-link" href="https://www.google.com/maps/search/Road+11,+Banani,+Dhaka" target="_blank" rel="noreferrer">Get directions <ArrowUpRight size={15} /></a>
              <div className="trial-microcopy">Online signup takes less than 2 minutes.</div>
            </Reveal>
            <Reveal delay="delay-2">
              <form className="contact-form" onSubmit={submitLead}>
                <label className="field-label" htmlFor="lead-name">Your name<input className="field-input" id="lead-name" name="name" placeholder="What should we call you?" required data-testid="input-lead-name" /></label>
                <label className="field-label" htmlFor="lead-email">Your email<input className="field-input" id="lead-email" name="email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Where can we send the details?" required data-testid="input-lead-email" /></label>
                <label className="field-label" htmlFor="lead-goal">Your goal<select className="field-input" id="lead-goal" name="goal" defaultValue="get-stronger" data-testid="select-lead-goal"><option value="get-stronger">Get stronger</option><option value="build-engine">Build my engine</option><option value="start-right">Start training properly</option><option value="meet-the-room">Just meet the room</option></select></label>
                <button className="btn-primary" type="submit" disabled={leadSubmitting} data-testid="button-submit-lead">{leadSubmitting ? 'Checking details...' : 'Send me the next step'} <ArrowRight size={16} /></button>
                <div className="form-demo-note">Demo mode — no information is sent.</div>
                {formStatus && <div className="form-status" role="status" data-testid="status-lead-form">{formStatus}</div>}
              </form>
            </Reveal>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="page-wrap">
          <div className="footer-top">
            <a className="brand-lockup" href="#top" data-testid="link-footer-brand"><span className="brand-mark"><Dumbbell size={17} /></span><span><span className="brand-word">APEX</span><span className="brand-sub">Training culture / Banani</span></span></a>
            <div className="footer-links">
              <a href="#classes" data-testid="footer-link-classes">Classes</a>
              <a href="#schedule" data-testid="footer-link-schedule">Timetable</a>
              <a href="#membership" data-testid="footer-link-membership">Membership</a>
              <a href="#trainers" data-testid="footer-link-trainers">Trainers</a>
              <a href="#contact" data-testid="footer-link-contact">Contact</a>
            </div>
          </div>
          <div className="footer-wordmark">APEX<span>GYM</span></div>
          <div className="footer-bottom"><span>© 2026 APEX Gym. Banani, Dhaka, Bangladesh.</span><span className="social-links"><a href="#contact" title="Demo link — no public profile available" aria-label="Instagram demo link"><Instagram size={15} /></a><a href="#contact" title="Demo link — no public profile available" aria-label="Facebook demo link"><Facebook size={15} /></a><a href="#contact" title="Demo link — no public profile available" aria-label="YouTube demo link"><Youtube size={15} /></a><a href="#contact" title="Demo link — no public profile available" aria-label="TikTok demo link"><Music2 size={15} /></a></span></div>
        </div>
      </footer>

      {booking && <div className="modal-backdrop" role="presentation" onClick={closeBooking}>
        <div className="modal" role="dialog" aria-modal="true" aria-labelledby="booking-title" aria-describedby="booking-description" onClick={(event) => event.stopPropagation()}>
          <button className="modal-close" ref={bookingCloseRef} type="button" onClick={closeBooking} aria-label="Close booking dialog" data-testid="button-close-booking"><X size={21} /></button>
          <span className="eyebrow" style={{ color: 'var(--orange)' }}>{booking.className ? 'Reserve a spot' : 'Start at APEX'}</span>
          <h3 id="booking-title">{booking.className ?? booking.plan ?? 'Your first session'}</h3>
          <p id="booking-description">Leave your details for this demo flow. No information will be sent or stored.</p>
          {bookingSubmitted ? <div className="modal-success" role="status">Demo confirmation — no information was sent.<button className="btn-primary" type="button" onClick={closeBooking}>Close demo</button></div> : <form className="modal-form" onSubmit={submitBooking}>
            <label className="sr-only" htmlFor="booking-name">Your name</label>
            <input className="field-input" id="booking-name" placeholder="Your name" required data-testid="input-booking-name" />
            <label className="sr-only" htmlFor="booking-phone">Your phone number</label>
            <input className="field-input" id="booking-phone" placeholder="01XXXXXXXXX" type="tel" inputMode="tel" pattern="[0-9+\s-]{7,}" required data-testid="input-booking-phone" />
            <button className="btn-primary" type="submit" disabled={bookingSubmitting} data-testid="button-confirm-booking">{bookingSubmitting ? 'Checking details...' : 'Request your spot'} <ArrowUpRight size={15} /></button>
          </form>}
        </div>
      </div>}
    </div>
  );
}

function Router() {
  return (
    <ErrorBoundary resetKey={useLocation()[0]}>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;